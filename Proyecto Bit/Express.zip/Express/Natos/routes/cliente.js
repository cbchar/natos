var express = require('express');
var router = express.Router();

const mongoose = require('mongoose');
const Cliente = mongoose.model('Cliente');

//metodo insertar
router.post('/insertar', (req,res,next)=>{
    const cliente = new Cliente(req.body)

    cliente.save(function(err, cliente){
        if(err){
            return next(err)
        }
        res.json(cliente)
    })
})//fin de metodo insertar

//metodo consultar
router.get('/consultar', async(req, res)=>{
    Cliente.find(function(err,cliente){
        if(err){
            return next(err)
        }
        res.json(cliente)
    })
})//fin de metodo consultar 

module.exports = router;
