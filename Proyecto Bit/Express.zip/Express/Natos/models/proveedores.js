const mongoose = require('mongoose');

const ProveedorSchema = new mongoose.Schema({
    id: Number,
    empresa: String,
    persona_contacto: String,
    rfc: String,
    tipo_persona: String
})

mongoose.model('Proveedor', ProveedorSchema);
