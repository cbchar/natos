var express = require('express');
var router = express.Router();

const mongoose = require('mongoose');
const Proveedor = mongoose.model('Cliente');

//metodo insertar
router.post('/insertar', (req,res,next)=>{
    const proveedor = new Proveedor(req.body)

    proveedor.save(function(err, proveedor){
        if(err){
            return next(err)
        }
        res.json(proveedor)
    })
})//fin de metodo insertar

//metodo consultar
router.get('/consultar', async(req, res)=>{
    Proveedor.find(function(err,proveedor){
        if(err){
            return next(err)
        }
        res.json(proveedor)
    })
})//fin de metodo consultar 


module.exports = router;
