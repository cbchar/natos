var express = require('express');
var router = express.Router();

const mongoose = require('mongoose');
const Empleado = mongoose.model('Empleado');

//Rutas para get, post, delete y put
//metodo insertar
router.post('/insertar', (req,res,next)=>{
    const empleado = new Empleado(req.body)

    empleado.save(function(err, empleado){
        if(err){
            return next(err)
        }
        res.json(empleado)
    })
})//fin de metodo insertar

//metodo consultar
router.get('/consultar', async(req, res)=>{
    Empleado.find(function(err,empleado){
        if(err){
            return next(err)
        }
        res.json(empleado)
    })
})//fin de metodo consultar 


module.exports = router;
